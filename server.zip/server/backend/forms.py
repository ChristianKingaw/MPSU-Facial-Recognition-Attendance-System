from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, PasswordField, SubmitField, SelectField, HiddenField
from wtforms.validators import DataRequired, Email, Length, ValidationError, EqualTo, Regexp, Optional
from models import Student, User, Class
from flask_login import current_user

# Login Form
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

# User Registration Form
class RegisterForm(FlaskForm):
    class Meta:
        csrf = False  # Disable CSRF for troubleshooting
    username = StringField('Username', validators=[
        DataRequired(),
        Length(min=4, max=64)
    ])
    email = StringField('Email', validators=[
        DataRequired(),
        Email(),
        Length(max=120)
    ])
    first_name = StringField('First Name', validators=[
        DataRequired(),
        Length(max=64)
    ])
    last_name = StringField('Last Name', validators=[
        DataRequired(),
        Length(max=64)
    ])
    password = PasswordField('Password', validators=[
        DataRequired(),
        Length(min=8, max=128)
    ])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(),
        EqualTo('password', message='Passwords must match')
    ])
    role = SelectField('Role', choices=[
        ('instructor', 'Instructor'),
        ('admin', 'Administrator')
    ])
    department = SelectField('Department', choices=[
        ('', 'Select Department'),
        ('BSIT', 'Bachelor of Science in Information Technology')
    ], validators=[Optional()])
    submit = SubmitField('Register')
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username already exists. Please choose a different one.')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Email address already registered.')

# Student Enrollment Form
class StudentForm(FlaskForm):
    class Meta:
        csrf = False  # Disable CSRF for troubleshooting
    first_name = StringField('First Name', validators=[
        DataRequired(),
        Length(max=64)
    ])
    last_name = StringField('Last Name', validators=[
        DataRequired(),
        Length(max=64)
    ])
    student_id = StringField('Student ID', validators=[
        DataRequired(),
        Regexp(r'^\d{2}-\d{5}$', message='Student ID must be in format YY-XXXXX')
    ])
    year_level = SelectField('Year Level', choices=[
        ('1st Year', '1st Year'),
        ('2nd Year', '2nd Year'),
        ('3rd Year', '3rd Year'),
        ('4th Year', '4th Year')
    ], validators=[DataRequired()])
    department = SelectField('Department', choices=[('BSIT', 'BSIT')], validators=[DataRequired()])
    email = StringField('Email', validators=[
        Email(),
        Length(max=120)
    ])
    submit = SubmitField('Enroll Student')
    
    def validate_student_id(self, student_id):
        student = Student.query.get(student_id.data)
        if student:
            raise ValidationError('Student ID already exists.')

# Class Form
class ClassForm(FlaskForm):
    class Meta:
        csrf = False  # Disable CSRF for troubleshooting
    class_code = StringField('Class Code', validators=[
        DataRequired(),
        Length(max=20)
    ])
    description = StringField('Description', validators=[
        DataRequired(),
        Length(max=255)
    ])
    room_number = StringField('Room Number', validators=[
        Optional(),
        Length(max=20)
    ], default="310")
    schedule = StringField('Schedule', validators=[
        DataRequired(),
        Length(max=100)
    ])
    instructor_id = SelectField('Instructor', coerce=int, validators=[DataRequired()])
    submit = SubmitField('Save Class')
    
    def validate_class_code(self, class_code):
        existing_class = Class.query.filter_by(class_code=class_code.data).first()
        if existing_class:
            raise ValidationError('Class code already exists.')

# Enrollment Form
class EnrollmentForm(FlaskForm):
    student_id = SelectField('Student', validators=[DataRequired()])
    class_id = HiddenField('Class ID', validators=[DataRequired()])
    submit = SubmitField('Enroll Student')

# Attendance Form
class AttendanceForm(FlaskForm):
    student_id = HiddenField('Student ID', validators=[DataRequired()])
    class_id = HiddenField('Class ID', validators=[DataRequired()])
    date = HiddenField('Date', validators=[DataRequired()])
    status = SelectField('Status', choices=[
        ('Present', 'Present'),
        ('Absent', 'Absent'),
        ('Late', 'Late')
    ], validators=[DataRequired()])
    submit = SubmitField('Save')

# Profile Update Form
class ProfileUpdateForm(FlaskForm):
    first_name = StringField('First Name', validators=[
        DataRequired(),
        Length(max=64)
    ])
    last_name = StringField('Last Name', validators=[
        DataRequired(),
        Length(max=64)
    ])
    email = StringField('Email', validators=[
        DataRequired(),
        Email(),
        Length(max=120)
    ])
    current_password = PasswordField('Current Password', validators=[Optional()])
    new_password = PasswordField('New Password', validators=[
        Optional(),
        Length(min=8, max=128)
    ])
    confirm_password = PasswordField('Confirm New Password', validators=[
        Optional(),
        EqualTo('new_password', message='Passwords must match')
    ])
    submit = SubmitField('Update Profile')
    
    def validate_current_password(self, field):
        if self.new_password.data and not field.data:
            raise ValidationError('Current password is required to change password.')
    
    def validate_email(self, email):
        if email.data != current_user.email:
            user = User.query.filter_by(email=email.data).first()
            if user:
                raise ValidationError('Email address already taken.')

# Profile Picture Update Form
class ProfilePictureForm(FlaskForm):
    profile_picture = FileField('Upload Picture', validators=[
        FileAllowed(['jpg', 'jpeg', 'png'], 'Images only (JPG, JPEG, PNG)')
    ])
    submit = SubmitField('Update Picture')
