class AttendanceValidationError(Exception):
    """Custom exception for attendance validation errors"""
    pass 